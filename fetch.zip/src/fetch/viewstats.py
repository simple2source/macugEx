#-*- conding:UTF-8 -*-

from fetchclass.showresult import *
from fetchclass.common import *
import sys

if __name__ == '__main__':
    para=''
    try:
        para=sys.argv[1]
    except:
        pass
    result_print(['cjol','51job'],database_path)
    if para == 'mail':
        result_email(['cjol','51job'],database_path)