#-*- coding:UTF-8 -*-

import os,sqlite3,datetime,time
from common import *


def get_restult(moudle_name='',database_path=''):
    '''功能描述：依次读取总数、昨天总数、今天总数、一个小时内总数、五分钟内总数。'''
    try:
        if moudle_name and os.path.isfile(database_path):
            total_num=0
            last_day_num=0
            today_num=0
            lasthour_num=0
            lastfivemin_num=0

            con = sqlite3.connect(database_path)
            cur = con.cursor()                       
            yestorday_str = (datetime.date.today()-datetime.timedelta(days=1)).strftime('%Y-%m-%d %H:%M:%S')
            today_str = datetime.date.today().strftime('%Y-%m-%d %H:%M:%S')
            onehour_before = (datetime.datetime.now()-datetime.timedelta(seconds=3600)).strftime('%Y-%m-%d %H:%M:%S')
            fivemin_before = (datetime.datetime.now()-datetime.timedelta(seconds=300)).strftime('%Y-%m-%d %H:%M:%S')
            if moudle_name == 'cjol':
                cur.execute('select total from total_count where moudle ="%s"' % moudle_name)
                data=cur.fetchall()
                try:
                    if data[0][0] >0:
                        total_num = data[0][0] 
                except:
                    pass
                    
                cur.execute('select sum(num) from cjol_seg_count where update_at >"%s" and update_at < "%s"' % (yestorday_str,today_str))
                data=cur.fetchall()
                try:
                    if data[0][0] >0:
                        last_day_num = data[0][0]
                except:
                    pass
                
                cur.execute('select sum(num) from cjol_seg_count where update_at > "%s"' % today_str)
                data=cur.fetchall()
                try:
                    if data[0][0] >0:
                        today_num = data[0][0]
                except:
                    pass
                cur.execute('select sum(num) from cjol_seg_count where update_at > "%s"' % onehour_before)
                data=cur.fetchall()
                try:
                    if data[0][0] >0:
                        lasthour_num = data[0][0]
                except:
                    pass
                cur.execute('select sum(num) from cjol_seg_count where update_at > "%s"' % fivemin_before)
                data=cur.fetchall()
                try:
                    if data[0][0] >0:
                        lastfivemin_num = data[0][0]
                except:
                    pass
            if moudle_name == '51job' or moudle_name == 'job51':
                cur.execute('select total from total_count where moudle ="51job"')
                data=cur.fetchall()
                try:
                    if data[0][0] >0:
                        total_num = data[0][0]
                except:
                    pass
                cur.execute('select sum(num) from job51_seg_count where update_at >"%s" and update_at < "%s"' % (yestorday_str,today_str))
                data=cur.fetchall()
                try:
                    if data[0][0] >0:
                        last_day_num = data[0][0]
                except:
                    pass
                cur.execute('select sum(num) from job51_seg_count where update_at > "%s"' % today_str)
                data=cur.fetchall()
                try:
                    if data[0][0] >0:
                        today_num = data[0][0]
                except:
                    pass
                cur.execute('select sum(num) from job51_seg_count where update_at > "%s"' % onehour_before)
                data=cur.fetchall()
                try:
                    if data[0][0] >0:
                        lasthour_num = data[0][0]
                except:
                    pass
                cur.execute('select sum(num) from job51_seg_count where update_at > "%s"' % fivemin_before)
                data=cur.fetchall()
                try:
                    if data[0][0] >0:
                        lastfivemin_num = data[0][0]
                except:
                    pass
            con.close()
        return [total_num,last_day_num,today_num,lasthour_num,lastfivemin_num]
    except Exception,e:
        return []
    
def result_print(moudle_list=[],dbfile=''):
    '''功能描述：将数据库查询结果进行打印输出'''
    try:
        for item in moudle_list:
            if item and dbfile:
                try:
                    result=get_restult(item,dbfile)
                    print '数据源名称 '+item+" 简历总数：%d 昨天总数：%d 今天总数：%d 近一个小时：%d 近五分钟：%d "%(result[0],result[1],result[2],result[3],result[4])
                except Exception,e:
                    pass
        return True
    except Exception,e:
        return False
    
def result_email(moudle_list=[],dbfile=''):
    '''功能描述：将数据库查询结果以邮件方式发送'''
    try:
        msg=""
        for item in moudle_list:
            if item and dbfile:
                try:
                    result=get_restult(item,dbfile)
                    msg += '数据源名称 '+item+" 简历总数：%d 昨天总数：%d 今天总数：%d 近一个小时：%d 近五分钟：%d <br>"%(result[0],result[1],result[2],result[3],result[4])
                    
                except Exception,e:
                    pass
        sendEmail('default_main', '抓取数据报告', msg,msg_type=1)
        return True
    except Exception,e:
        return False
    
if __name__=='__main__':
    print 'test...'
    result_print(['cjol','51job'],database_path)
    #result_email(['cjol','51job'],database_path)