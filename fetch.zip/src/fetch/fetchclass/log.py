#-*- coding:utf-8 -*-

import logging,os
from logging.handlers import TimedRotatingFileHandler
from common import log_dir
#logdir=os.path.dirname(os.path.abspath(__file__))
logdir=log_dir
if not os.path.exists(logdir):
    os.makedirs(logdir)
logpath=os.path.join(logdir,'fetch.log')    

def init_log():  
    '''功能描述：初始化日志参数'''
    logger = logging.getLogger()
    console = logging.StreamHandler()
    console.setLevel(logging.DEBUG)
    logger.setLevel(logging.DEBUG)
    formatter = logging.Formatter("[%(asctime)s][%(filename)s][%(funcName)s][Line:%(lineno)d][%(levelname)s]:%(message)s")
    fileHandle = logging.handlers.RotatingFileHandler(logpath, maxBytes=(10*(1<<20)), backupCount=5)
    fileHandle.setFormatter(formatter)
    logger.addHandler(fileHandle)
    logger.addHandler(console)
init_log()