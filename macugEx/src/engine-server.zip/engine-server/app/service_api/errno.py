# -*- coding: utf-8 -*-
"""
错误码定义
"""
E_serv_nofind = 20001
E_bad_serv_passwd = 20002
E_quest_nofind = 20003
E_quest_inflight = 20004
E_quest_finish = 20005
E_quest_unstart = 20006
E_quest_bad_serv_id = 20007
