CentOS7:
终端下执行sh install_centos7.sh启动项目
