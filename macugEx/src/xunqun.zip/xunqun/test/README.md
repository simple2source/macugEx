#### 单元测试模块

用 `python testrunner.py` 进行全量的测试

用 `python testrunner.py somedir` 执行某个目录下的测试用例

用 `python testrunner.py somedir/somefile` 执行单个测试用例
