# antd-demo

## Environment

```
node >= 4
```

## Code Style

https://github.com/airbnb/javascript

## Develop

```
npm run dev
```

访问 http://127.0.0.1:8989 

## Build

```
npm run build
```
